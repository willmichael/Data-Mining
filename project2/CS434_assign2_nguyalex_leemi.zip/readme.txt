To run:

./setup.sh
