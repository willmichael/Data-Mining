
run
 ./setup.sh


to change file:
    change variable at line 129 for filename="<your file>"
