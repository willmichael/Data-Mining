run setup.sh


ex:
./setup.sh
